from schema.parsers.jsonld import format_jsonld


def test_format_jsonld():
    pass
