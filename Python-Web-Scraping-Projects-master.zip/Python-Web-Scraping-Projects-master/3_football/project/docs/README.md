This directory contains various documentation and sample documents. 

`genesis.html` - refers to page that is used to design the parser of individual team.
`genesis_embed.json` - refers to extracted json data from genesis.html about individual teams. This is unparsed json that is later parsed in our crawler to produce final item.
`sample_<date>.json` - refers to output sample of this crawler of a single item.