# Python Web Scraping Projects Chapter 5

This is repository for project covered in "Python Web Scraping Projects" book by Bernardas Ališauskas and Packt publishing.

## Code

The fully developed project code is contained in [/project](./project) directory.  
For additional code snippets that are used in the book or are mentioned as extras see [/snippets](./snippets) directory.  

## Casts

There is video material included with the book; see [videos](./videos) directory.